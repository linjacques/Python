# Algorithmique et Programmation 1 - TD2

# exercice 1 - equivalence d'expressions booléennes
# Deux expressions booleennes sont equivalentes quand ces deux expressions s'evaluent toujours vers
# la m^eme valeur booleenne pour toutes les valeurs possibles des variables qui apparaissent dans ces
# expressions.
# Par exemple, pour x entier, (x > 10 and x < 12) est equivalente a (x == 11). Par contre, (x > y) et
# (x! = y) ne sont pas equivalentes.
# Dire si les expressions suivantes sont equivalentes pour x entier :

# 1 (x>y or x<y) et (x!=y)
print('exo 1')
print('ils sont equivalent car dans tous les cas x est différent de y, x jamais égal à y')

# 2
print('ils sont equivalent car le premier terme exclue 3/4/5 ce q'
      'ui correspond au deuxieme terme qui commence à partir de 2 et comprend les valeurs supérieur à 6')

# 3
print('pas equivalent car y a :  x == y dans le premier terme')

# 4
print('equivalent car exactement le meme terme')

# exercice 2 - simplification d'expression booleennes
print()
print('exo 2')
# 1. x > 5 and x > 7
print('x>7')

# 2. x == y and x == z and y == z
print('x==y and y==z')

# 3. x == 17 or (x! = 17 and x == 42)
print('x>=17 and x<=42')

# 4. x > 5 or (x <= 5 and y > 5)
print('x>=5 and y>5')

# exercice 3

# 1
print('suite 1')
a = 2
b = a * a + 3
c = b - a
if (a == c) or (a < b):  # deuxieme condition remplie donc on rentre
    # b= 2 * 2 + 3 = 7
    # c=  7 - 2 = 5
    a = 2 * c  # = 10
    print('valeur de la variable : 10', a)
else:  # condition non-remplie donc on sort
    a = c - b  # = 7 - 5 = -2
    print('valeur de la variable : -2', a)
if (b < a) and (b > c):  # la condition est vérifiée donc on rentre dans tous les cas

    b = 2 * c + a  # b= 2 * 5 + 2 = 12
    c = 3 * a   # c= 3 * 2 = 6
    print('nouvelle valeur de B et C :', b, c)
if (c % b == 0) or (not(a < b) and not(a < c)):   # si
    a, b = 0, 0
    print('nouvelle de valeur de', a)
else:
    c = b - a

# exercice 4
print('exo 4')
"""
x = int(input("Donnez un entier x : "))
y = int(input("Donnez un entier y : "))
if ((x <= y) or (x >= y + 1)) : #
    if ((x <= y) and (x < y)) :
        if (x < -x) :
            a = -x
            print(a)
        else :
            print(x)
    else :
        if (y * y * y < 0) :
            print(-y)
        else :
            print(y)
else :
    print(y)
s"""
# 1 Expliquer ce que fait ce programme
""""ce programme compare la valeur X et Y saisie par l'user, et affiche uniquement l'entier 
(négatif ou positif) le plus petit des deux"""
# 2 Simplifier ce programme
"""x = int(input("Donnez un entier x : "))
y = int(input("Donnez un entier y : "))

if x <= y:  
    print(x)  
else:  # dans le cas contraire : si X inf ou égal à Y
    print(y) 
"""
# exercice 5
print('exo 5')
"""""""""
x = int(input("Donnez un entier : "))
y = int(input("Donnez un entier : "))
z = int(input("Donnez un entier : "))
grand = 0
moyen = 0
petit = 0

if (x>y and x>z):
    grand = grand + x
if(y>x and y>z):
    grand = grand + y
if(z>y and z>x):
    grand = grand + z
if((x>y and x<z) or (x<y and x>z)):
    moyen = moyen + x
if((y>x and y<z) or (y<x and y>z)):
    moyen = moyen + y
if((z>y and z<x) or (z<y and z>x)):
    moyen = moyen + z
if(x<y and x<z):
    petit = petit + x
if(y<x and y<z):
    petit = petit + y
if(z<y and z<x):
    petit = petit + z

print('grand :', grand,'moyen :', moyen,'petit :', petit)
"""""
# exercice 6
print('exo 6 : ALGO d euclide')
"""""""""
dividende=int(input('entier positif 1 :'))
diviseur=int(input('entier positif 2 :'))
if (diviseur and dividende !=0):
    reste= dividende%diviseur # le pgcd
    a=dividende//diviseur # algo d'euclide
    quotient = a * diviseur + reste # le reste
    print('reste', reste)
    print('a', a)
    print(dividende, '=', diviseur,  '*', a , '+', reste)
else:
    print(' ERREUR diviseur ou dividende négatif ou nul')
"""""""""
# exercice 7
print('exo 7 :')
"""""""""
sec = int(input('entier en seconde :'))
if sec > 0:
    def converion(sec):
        seconde = sec % (24 * 3600)
        heure = sec // 3600
        seconde %= 3600
        minute = sec / 60
        seconde %= 60
        minute %=60
        return "%dh : %dmin : %dsec" %(heure, minute, seconde)
    print(sec, 'secondes correspond à', converion(sec))
else:
    print('ERREUR, veuillez saisir un entier >0 !')
"""""
# exercice 8
print('exo 8 :')
"""""""""
nom = input('veuillez entrer le nom d un étudiant :')
note1 = int(input('entrer la note 1 :'))
note2 = int(input('entrer la note 2 :'))
note3 = int(input('entrer la note 3 :'))

moyenne = (note1+note2+note3)/3
if (note1 and note2 and note3 >=9):

    if (moyenne>=10 or min(note1, note2, note3)>=8): # fonction min() qui cherche la plus petite valeurs
        print(nom, 'est accepté !')
    else:
        print(nom, 'est refusé')
else:
    print(nom, 'est refusé')
"""
# exercice 9
print('exo 9 :')
"""""""""
entier1 = int(input('entier 1 :'))
entier2 = int(input('entier 2 :'))
abs(entier2) # fonction abs() qui est fait pour les valeurs absolues!
if (abs(entier1)>abs(entier2)):
    print('le plus grand en valeur absolue est :', entier1)
else:
    print('le plus grand en valeur absolue est :', entier2)
    """""

# exercice 10 :
print('exo 10')
"""""""""
tickets = int(input('veuillez mettre le nombre total de tickets pris pour le groupe 1 :'))
for i in range (6): # départ à 0 et arrivé à 5, cadence de 1
    prix_ticket = 8*i
    for j in range (6, 11):
        prix_ticket = 6*j
        for k in range (11, tickets):
            prix_ticket = 5.50*k
print('le prix total pour', tickets, 'tickets, revient à', prix_ticket, 'euros')
"""
# exercices 11
print('exo 11 :')

entier = int(input('saisir un entier pour l ordinal :'))
def ordinaltg(n): # pour mettre le 21st et 22nd et 23rd et 24th des dates
 return    str(n) + {1: 'st', 2: 'nd', 3: 'rd'}.get(4 if 10 <= n % 100 < 20 else n % 10, "th") # ordinal
print('bonjour le ', ordinaltg(entier), 'gentleman')
