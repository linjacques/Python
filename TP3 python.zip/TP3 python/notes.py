# exercice 5
print('exo 5 :')
"""""""""
nombre_notes = 5
note_min = 20
note_max = 0
indice_min = 0
indice_max = 0
for i in range(1, nombre_notes + 1) :
    print("Veuillez entrer la note numéro", i)  # Va être demandé 5 fois
    note_saisie=float(input())  # convertie la note saisie par l'user en float (chiffre à virgule désormais possible)
    while note_saisie > 20 or note_saisie < 0 : # blindage : on ne veut pas de note <0 et >20
        print("Attention! une note est comprise entre 0 et 20")
        print("Veuillez entrer la note numéro", i)
        note_saisie=float(input())
    if note_min > note_saisie :
       note_min = note_saisie
       indice_min = i
    if note_max < note_saisie :
       note_max = note_saisie
       indice_max = i
print(nombre_notes, note_min, indice_min, note_max, indice_max)
"""""
# 1 Expliquez ce que fait ce programme
""" Ce programme est composé de plusieurs éléments important :
1 - le nombre de note : 5 max, rentré dans une boucle for, comme paramètre pour définir une intervalle de valeur : 1 à 6 
2 - le nombre de note = 5, sera donc demandé 5 fois de rentrer une note
3 - le blindage avec la boucle while : il est là pour s'assurer qu'on ne rentre pas un float <0 ou >20
4 - les deux boucles IF sont là pour trouver la note_min et la note_max et renseigner leur indice, càd la note numéro combien
5 - une fois trouvé, afficher l'indice avec note la plus faible et l'indice avec note la plus élevée"""

# 2 Recopiez-le dans un fichier notes.py, et verifiez que votre reponse precedente est correcte
""""""""" obtenu dans le compilateur
Veuillez entrer la note numéro 1
13
Veuillez entrer la note numéro 2
14
Veuillez entrer la note numéro 3
19
Veuillez entrer la note numéro 4
3
Veuillez entrer la note numéro 5
1
5 1.0 5 19.0 3      #5: nb de notes max
                    #1.0 : la note la plus faible
                    #5 : l'indice de la note la plus faible
                    #19.0 : la note la plus élevé
                    #3 : l'indice de la note la plus élevé

Process finished with exit code 0
"""

# 3 Modifiez le print final afin que l'affichage des resultats soient plus clairs
"""""""""
nombre_notes = 5
note_min = 20
note_max = 0
indice_min = 0
indice_max = 0
for i in range(1, nombre_notes + 1) :
    print("Veuillez entrer la note numéro", i)  # Va être demandé 5 fois
    note_saisie=float(input())  # convertie la note saisie par l'user en float (chiffre à virgule désormais possible)
    while note_saisie > 20 or note_saisie < 0 : # blindage : on ne veut pas de note <0 et >20
        print("Attention! une note est comprise entre 0 et 20")
        print("Veuillez entrer la note numéro", i)
        note_saisie=float(input())
    if note_min > note_saisie :
       note_min = note_saisie
       indice_min = i
    if note_max < note_saisie :
       note_max = note_saisie
       indice_max = i
print('nombre de notes max :', nombre_notes,' note la plus basse :',  note_min,'au controle numéro :',  indice_min, 'note la plus élevé', note_max,'au controle numéro :',  indice_max)
"""
# 4 Ajoutez le calcul de la moyenne des notes
"""""""""
nombre_notes = 5
note_min = 20
note_max = 0
indice_min = 0
indice_max = 0
somme_note = 0

for i in range(1, nombre_notes + 1):
    print("Veuillez entrer la note numéro", i)  # Va être demandé 5 fois
    note_saisie = float(input())  # convertie la note saisie par l'user en float (chiffre à virgule désormais possible)
    somme_note = note_saisie + somme_note
    moyenne = somme_note/5
    while note_saisie > 20 or note_saisie < 0:  # blindage : on ne veut pas de note <0 et >20
        print("Attention! une note est comprise entre 0 et 20")
        print("Veuillez entrer la note numéro", i)
        note_saisie = float(input())
    if note_min > note_saisie:
       note_min = note_saisie
       indice_min = i
    if note_max < note_saisie:
       note_max = note_saisie
       indice_max = i

print('nombre de notes max :', nombre_notes,' note la plus basse :',  note_min,'au controle numéro :',
      indice_min, 'note la plus élevé', note_max,'au controle numéro :',  indice_max,
      'moyenne de :', moyenne)

"""
# 5
"""""""""
nombre_notes = 100000
note_min = 20
note_max = 0
indice_min = 0
indice_max = 0
somme_note = 0

for i in range(1, nombre_notes):
    print("Veuillez entrer la note numéro", i)  # Va être demandé 5 fois
    note_saisie = float(input())  # convertie la note saisie par l'user en float (chiffre à virgule désormais possible)
    somme_note = note_saisie + somme_note
    moyenne = somme_note/5
    while note_saisie > 20 or note_saisie < 0:  # blindage : on ne veut pas de note <0 et >20
        print("interruption : vous avez rentré une note >20 ou <0")
        note_saisie = float(input())
        break
    if note_min > note_saisie:
        note_min = note_saisie
        indice_min = i
        if note_max < note_saisie:
            note_max = note_saisie
            indice_max = i

print('nombre de notes max :', nombre_notes,' note la plus basse :',  note_min,'au controle numéro :',
      indice_min, 'note la plus élevé', note_max,'au controle numéro :',  indice_max,
      'moyenne de :', moyenne)
"""""

