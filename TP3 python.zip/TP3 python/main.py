# algorithmique et programmation

# exercice 1
print('exo 1 :')
# 1
"""""""""
i = 1
while i <= 5 :
    print(i)
    i = i+1
"""
"""la suite 1 affiche : 1 
                        2
                        3
                        4
                        5"""
# 2
print()
"""""""""
i = 1
while i <= 5 :
    i = i+1
    print(i)
    """""
"""""la suite 2 affiche : 2
                          3
                          4
                          5
                          6"""
# 3
"""""""""
i = 1
while i > 0 :
    print(i)
    i = i + 1
    """
"""boucle infini augmentant de 1 par 1"""

# 4
"""""""""
i = 1
while i > 10 :
    print(i)
    i = i + 1
""
""""n'affiche pas car i=1 or pour rentrer dans la boucle il aurait fallu que i>10"""

# exercie 2
print('exo 2 :')
"""""""""
# 1
for i in range(50, 100, 10) :
    print(i)
    """
"""la boucle for affiche : 50
                           60
                           70
                           80
                           90"""
# 2
"""""""""
for i in range(50, 100, 10) :
    print(10)
    """""
"""la suite affiche : 10
                      10
                      10
                      10
                      10"""
# 3
"""""""""
x = 0
for i in range(0, 5, 1) :
    x = x + 5
    print(x)
    """
""""la suite affiche : 5
                       10
                       15
                       20
                       25"""
# 4
"""""""""
x = 0
for i in range(5) :
    x = x + 5
    print(x)
    """""
""""suite : 5
            10
            15
            20
            25"""

# exercice 3
print('exo 3 :')

# 1
""""""""""
n = 6
i = 1
compte = 0
while i <= n :
    if n % i == 0 :
        compte = compte + 1
        i = i + 1
        print(compte)
        """""
"""affiché en sortie : 1
                       2
                       3"""
# 2
"""""""""
n = int(input("Donnez un entier : "))
compte = 0
while n % 2 == 0:  # SURTOUT ne pas mettre 0 car sinon boucle sur l'infini
    compte = compte + 1
    n = n / 2
    print(compte)
    """
"""affiche le reste de la division euclidienne """

#  exercice 4
print('exo 4 :')

# 1 Expliquez ce que fait ce programme
"""""""""
s = 0
for i in range(0, 101, 2):  
    s = s + i * i  # au carré
    print(s)
    """
"""boucle for, allant de 0 à 100 avec un pas de 2
à chaque pas de 2, le programme execute de la manière suivante :
i=0 , la situation de départ, le programme renverra 0
i=2, ici le programme a avancé de 2 pas donc
        s = 0 + 2*2 = 4
i=4, 4 pas
        s = 4 + 4*4 = 20
i=6, 6 pas
        s = 20 + 6*6 = 50
ainsi de suite... cette boucle s'executera 50 fois en tout jusqu'à s'arreter sur la 100e valeur de i"""

# 2 Modifiez ce programme de facon a ce qu'il calcule la somme des cubes de 0 a 42
"""""""""
s = 0
for i in range(0, 43):
    s = s + i * i * i # au cube
    print(s, '=', s,'+', i, '*', i, '*', i)
"""""
# exercice 7
"""""""""
print('exo 7 :')
somme_entier = 0  # conserve la valeur de some_entier
print('veuillez saisir un entier :')
entiers = int(input())
while not entiers == 0:  # tant que entier n'est pas =0, demander en boucle le print
    print('veuillez saisir un entier :')
    entiers = int(input())
    somme_entier = entiers + somme_entier  # on va pouvoir additionner les notes saisies par l'user
print('la somme des entiers saisie est :', somme_entier)
"""

# exercice 8
"""""""""
print('exo 8 :')
nb_entier = 5
tableauvaleurs = [] # tableau qui va récupérer les valeurs saisies par l'user

print('entrez entier:')
chiffre = int(input())
tableauvaleurs.append(chiffre)  # insère la valeur saisie par l'user dans le tableau
for i in tableauvaleurs: # parcours le tableau à la recherche du chiffre 42
    print('entrez entier:', i)
    chiffre = int(input())
    tableauvaleurs.append(chiffre)  # insère la valeur saisie par l'user dans le tableau
if chiffre == 42:
    print(chiffre)
    print('gagné !')

else :
    print('perdu !')


"""""
# exercice 9 :
"""""""""
print('exo 9 :' )
Un = int(input('saisir l entier Uo:'))  # Un peut etre impair ou pair
term = int(input('saisir l entier de terme:')) # U combien?
for i in range (1, term+1):  # répéter term+1 fois l'opération
    if Un % 2 == 0:  # si pair
        Un = Un/2
    else:  # si impair
        Un = Un*3+1
    print(Un)
    print('le terme U', i, 'de la suite est égal à:', Un)

"""
# exercice 10

print('exo 10:' )
grain = 1
case = 65  # échiquier
for i in range(1, case):
    grain = grain*2
    print('nb de grain', grain, 'par case', i)
    # on nous dit que chaque grain de riz pèse 0.25 gramme
    grain_blé = 758000000*1000*1000*4
    année = grain/grain_blé

print('nombre d année pour rembourser ce génie:', année)
