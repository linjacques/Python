# exercice 6
print('exo 6 :')
"""""""""
hauteur = int(input("Entrez un entier : "))
for i in range(1, hauteur + 1) :
    print("*" * i)
    """
# 1 Expliquez ce que fait ce programme
"""le programme demande à l'user de saisir un entier positif :
l'entier sera augmenté de 1, appelé hauteur
la valeur de l'entier correspond aussi à la taille max de la boucle for
dans cette boucle for, le print va print hauteur+1 fois : *"""
# 2 Recopiez-le dans un fichier triangle.py, et verifiez que votre reponse precedente est correcte
"""""""""
Entrez un entier : 6
*
**
***
****
*****
******

Process finished with exit code 0
"""""
# 3

hauteur = int(input("Entrez un entier : "))

for i in range(1, hauteur + 1):
    for j in range (1, hauteur-i + 1):
        print("  ", end="")
    for j in range (1, 2*i-1+1):
        print("* ", end="")
    print()

