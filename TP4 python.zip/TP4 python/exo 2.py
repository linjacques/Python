# exercice 2 :
print('exo 2 :')
"""""""""
chaine = "Python !"
res = 0
for c in chaine :
    res = res + 1
    print(res)
    """""
# 1. Ecrire la table de simulation de ce programme
"""" table de simulation
exo 2 :
1
2
3
4
5
6
7
8

Process finished with exit code 0"""
# 1 Que fait ce programme ?
"""le programme affiche res de 0 à chaine+1"""
# 3 Modifier ce programme de faccon a ce qu'il retourne la chaine donnee au depart en doublant
# chaque lettre, soit dans cet exemple PPyytthhoonn !!
chaine = "Python !"
res = chaine
for c in chaine:
    res = c*2
    print(res, end='')  # le end='' c'est pour éviter que le print aille à la ligne
    