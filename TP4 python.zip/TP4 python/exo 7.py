# exo 7 :
print("exo 7 :")

print("tapez une phrase :")
phrase = str(input())
# la fonction join() fusionne tous les caractères résultant de
# l'itération inversée dans une nouvelle chaine, ici 'verlan'
verlan = ''.join(reversed(phrase))  # fonction reversed() inverse la chaine
print("verlan :", verlan)