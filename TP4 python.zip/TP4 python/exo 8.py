# exo 8 :
print("exo 8 :")
phrase = str(input("tapez une phrase :"))
chaine = []
print("de quel caractère souhaitez-vous connaitre les occurrences ?")
occurrences = input()
# position, donne la position de i à chaque itération
# enumerate()
for position, i in enumerate(phrase):  # parcours lettre par lettre dans 'phrase'
    if i == occurrences:  # si la lettre saisie par user est égal à une des lettres du mot
        chaine.append(position)  # alors ajouter la lettre dans la liste 'chaine'
print()
print("la lettre", occurrences, "apparait à la position", chaine)


