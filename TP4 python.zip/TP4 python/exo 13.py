# exercice 13
print("exo 13 :")
chaine = input("rentrez une chaine de caractère :")
# La fonction reversed() prend une séquence d’éléments et renvoie un itérateur inverse pour cette séquence
if str(chaine) == "".join(reversed(chaine)):
    print(chaine, "est un palindrome")
else:
    print(chaine, "n'est pas un palindrome")