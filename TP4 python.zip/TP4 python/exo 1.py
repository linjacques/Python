# algorithmie et programmation

# exercice 1 :
"""""""""
print('exo 1 :')
ch = "Avec consonnes"
cha = ch[0]
cha = cha + ch[2]
cha = cha + ch[6]
cha = cha + ch[9]
cha = cha + ch[12]
print(cha[:])
"""""
"""
exo 1 :
Aeooe

Process finished with exit code 0"""

