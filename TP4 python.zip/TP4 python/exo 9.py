# exercice 9 :
print("exo 9 :")
liste = []
chaine = str(input("tapez une phrase :"))
liste.append(chaine)
print("quel caractère souhaitez-vous supprimer ?")
caracteres = str(input())
for i in caracteres:
    if caracteres == i:  # si la lettre saisie est égal à une lettre de la chaine
                        # .replace créer une nouvelle variable où la lettre sera supprimée
        chaine = chaine.replace(caracteres, "")  # le ,"" cest pour douiller le deuxieme argument
print(chaine)
