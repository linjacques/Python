# exercice 3
print('exo 3:')
# 1 Soit la liste [1, 3, 5, 7, 9, 11, 13, 15, 17]. Quelle est sa longueur ? A quel indice
# trouve-t-on la valeur 1 ? La valeur 17 ? La valeur 9 ?
print('1')
liste = [1, 3, 5, 7, 9, 11, 13, 15, 17]
len(liste)  # fonction len() qui permet trouver la longueur d'une liste
print('longueur de la liste:', len(liste))  # longueur de la liste = 9
""""la valeur 1 se trouve à l'indice 0,
    la valeur 17 se trouve à l'indice 8
    la valeur 9 se trouve à l'indice 4"""

# 2 Soit la liste lst = [2, 2, 3, 3, 4, 5, 7]. Quelle est sa longueur ? Que vaut l'expression
# lst[0] ? lst[4] ? lst[7] ?
print('2')
liste2 = [2, 2, 3, 3, 4, 5, 7]
len(liste2)
print('la longueur de liste2:', len(liste2))
""""lst[0] vaut 2
    lst[4] vaut 4
    lst[7] vaut null car la liste va de 0 à 6 et pas de 0 à 7"""
