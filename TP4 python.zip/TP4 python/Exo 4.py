# exercice 4
print(' exo 4:')
"""""""""
liste = [32, 5, 76, 8, 13, 2, 14, 25]
li = []
lp = []
i = 0
while i < len(liste) :
    if liste[i] % 2 == 0 :
        lp.append(liste[i])
    else :
        li.append(liste[i])
    i = i + 1
print("li : ", li)
print("lp : ", lp)
"""
# 1 Ecrire la table de simulation de ce programme
"""" tableau de simulation
li :  [5, 13, 25]
lp :  [32, 76, 8, 2, 14]

Process finished with exit code 0"""

# 2 Que fait ce programme ?
"""ce programme contient 2 listes : li et lp
- la boucle while est là pour s'assurer que i ne dépasse pas la taille max du tableau
- le if est dans le while pour verfier que chaque valeurs des tableaux est impair pour li et pair pour lp
- affiche les nombres impairs dans le premier tableau li
- affiche les nombres pairs dans le deuxième tableau lp"""

# 3 Modifier ce programme de facon a ce qu'il analyse un par un tous les elements d'une liste de
# chaines de caracteres, et genere une liste contenant les mots de plus de 4 caracteres, et une liste
# contenant les mots de 4 caracteres ou moins.
"""""""""
liste = ['bonjour', 'a', 'lol', 'bonsoir', 'patate_douce', 'mdr', 'ok']
mot4 = []
motnon4 = []
i = 0
while i < len(liste) :
    if len(liste[i]) > 4: # si la taille de la chaine (mot) >4
        mot4.append(liste[i])  # ajouter mot dans ce tableau
    else:
        motnon4.append(liste[i])
    i = i + 1
print("mot dont nb de lettre >4 ", mot4)
print("mot dont nb de lettre <=4", motnon4)
"""""
# Donner les valeurs des variables à la fin de la suite d'instructions suivante :
set1 = {"a", "b", "c"}
set2 = {1, 2, 3, 4}
#print("set1",set1)
#print("set2", set2)
set2.update({5})  # Ajoute un entier à la fin de la liste set2 SSI l'entier est > 4
print("valeur set 2 après update :",set2)
set3 = set1 | set2
print()
print("set3", set3)
set3.discard(2)  # retire la valeur 2 de la liste set3
print()
print("set3.discard(2)", set3)
set3.remove("b")  # retire le b de set3
print()
print("set3.remove('b')", set3)
set4 = set1 & set3
print()
print("set4", set4)
set2.clear()
print()
print("set2.clear()", set2)
set2 = set3 - set4
print()
print("set2", set2)