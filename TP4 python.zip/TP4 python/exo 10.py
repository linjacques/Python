# exercice 10 :
print("exo 10 :")

phrase = str(input("tapez une phrase :"))
liste = phrase.split()  # fonction .split fractionne une chaine de caractères à chaque espace
print(liste)


