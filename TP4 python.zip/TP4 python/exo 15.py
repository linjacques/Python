# exercice 15 :
print("exo 15 :" )
liste=[4,87,2,782,87,124,87,1,3,124]
r=[]
k=0
num=0
verif=0
for i in range(len(liste)):
    for j in range(len(liste)):
        if(liste[i]==liste[j]):
            num=num+1
            if(num>=2):
                    print(liste[i])
                    if(r!=[]):
                        for k in range(len(r)):
                            if(r[k]==liste[i]):
                                verif=1
                        if(verif==0):
                            r.append(liste[i])
                    else:
                        r.append(liste[i])
    num=0
    verif=0
print("Liste:",liste)
print("Ensemble des éléments:",r)

