# exercice 12
print("exo 12 :")

notes = [17, 8, 19, 4, 15, 11, 13]
noms = ["adele", "bernard", "charles", "denise", "eric", "fabio", "ginette"]
if(len(notes)==len(noms)):
    for i in range(len(notes)):
        if(notes[i]<10):
            print(noms[i],notes[i],"Echec")
        elif(notes[i]>=10 and notes[i]<12):
            print(noms[i], notes[i], "P")
        elif(notes[i]>=12 and notes[i]<14):
            print(noms[i], notes[i], "AB")
        elif(notes[i]>=14 and notes[i]<16):
            print(noms[i], notes[i], "B")
        elif(notes[i]>=16 and notes[i]<18):
            print(noms[i], notes[i], "TB")
        elif(notes[i]>=18 and notes[i]<20):
            print(noms[i], notes[i], "Félicitations")
else:
    print("Il manque des notes ou des noms dans une des liste")