# exercice 11

print("exo 11 :")
liste=[4,6,45,78]
val=54
n=0
for i in range(len(liste)):
    if(liste[i]==val):
        n=i
if(n!=0):
    print("La derniere occurence de la valeur est a l'indice",n)
else:
    print("La valeur n'est pas comprise dans la liste")


print("2.")
chaine="jgojrgeopzvpt"
cara="w"
i=0
n=0
j=2
while(j!=0):
    if (i == len(chaine)):
        j = 0
    else:
        if(chaine[i]==cara):
            n=i
            i=len(chaine)
    i=i+1
if(n!=0):
    print("La premiere occurence du caractere est",n)
else:
    print("Le caractere n'apparait pas dans la chaine")