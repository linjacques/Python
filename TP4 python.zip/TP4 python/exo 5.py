# exercice 5 :
print("exo 5 :")
entier = [1, 2, 3, 9, 8, 2]
sum(entier)  # additionne chaque valeur de la liste

print("somme des valeurs de la liste :", sum(entier))
print("élément minimum :", min(entier), "élément maximum :", max(entier))