# exercice 6

print("exo 6 :")

entier = []  # liste vide où les valeurs saisies par l'user seront ajoutée par la suite
liste = int(input("combien d'entier comporte votre liste ?"))
i = 0
while i < liste:
    print("quel est l'entier", i, "de voter liste ?")
    valeur = int(input())
    entier.append(valeur)  # rentre les valeurs saisies par users dans la liste pour les stocker
    sum(entier)  # additionne chaque valeur de la liste
    i = i + 1
# il nous faut d'abord trier la liste 'entier'
entier1 = entier[:]  # nouvelle variable prenant la liste 'entier' non trié de base
entier1.sort()  # fonction .sort() qui fait le trie automatiquement 
if (entier1 == entier):  # vérifie si entier1 (qui est une version triée de 'entier') est égal à 'entier' qui est non-trié
    print("la liste est bien triée!", entier1)
else:
    print("la liste n'est pas triée!", entier)