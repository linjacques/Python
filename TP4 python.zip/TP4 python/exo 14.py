# exercice 14 :
print("exo 14 :" )
liste=[4,87,2,54,87,124,87,45,3,124]
num=0
max=0
for i in range(len(liste)):
    if(liste[i]>max):
        max=liste[i]
        num=0
    if(liste[i]==max):
        num=num+1
print("Le maximum de la liste est",max,"et il apparait",num, "fois")
