#exo1
CarreMagique = [[2, 7, 6],
                [9, 5, 1],
                [4, 3, 8]]


nb = int(input("appartient liste donner chiffre :"))
def appartient_listeliste(CarreMagique):
    n = len(CarreMagique)    #nb de ligne
    nc = len(CarreMagique[0]) #nb de colone
    for i in range(n):
        for j in range(nc):
            if not 1<= CarreMagique[i][j] <= n**2 :
                return False
    return True
print(appartient_listeliste(CarreMagique))
#2
#3


def somme_ligne(CarreMagique, numL):
    s = 0
    ligne = CarreMagique[numL]
    for num in ligne:
        s = s + num
    return s
nbs = int(input(("somme de la ligne : ")))
if nbs < len(CarreMagique):
    print(somme_ligne(CarreMagique,nbs))
else:
    print("ligne n existe pas")
#4
numb = int(input(("verif somme ligne : ")))
def verif_lignes(CarreMagique, A):
    if somme_ligne(CarreMagique,0) == somme_ligne(CarreMagique,1) == somme_ligne(CarreMagique,2):
        if somme_ligne(CarreMagique, 0) == A:
            print("true")
        return True
    else:
        return False

print(verif_lignes(CarreMagique, numb))

#5

colo = int(input("choisir la colone 1,2 ou 3 colone :"))
def colone_aff(CarreMagique,colo):
    newlist = []
    if colo <= 3:
        nub = colo - 1
        newlist = [CarreMagique[0][nub], CarreMagique[1][nub], CarreMagique[2][nub]]
    return newlist

print(colone_aff(CarreMagique, colo))
#6
def verif_colone(CarreMagique, numC):
    n = len(CarreMagique)
    s = 0
    for i in range(n):
        s = s + CarreMagique[i][numC] # s+= ligne[numc]
    return s
print("somme de la colonne : " + str(verif_colone(CarreMagique, colo)))

if verif_colone(CarreMagique, colo) != 15:
    print("False")
else:
    print("True")

#7
CarreMagiqua = [[4, 14, 15, 1],
                [9, 7, 6, 12],
                [5, 11, 10, 8],
                [16, 2, 3, 13]]
def diagonale2(CarreMagique):
    n = len(CarreMagique)
    newlist = []
    for i in range(n):
        #newlist = newlist.extend(CarreMagique[i][i])
        newlist += [CarreMagique[i][n-1 -i]]
    return newlist

def diagonale1(CarreMagique):
    n = len(CarreMagique)
    newlist = []
    for i in range(n):
        #newlist = newlist.extend(CarreMagique[i][i])
        newlist += [CarreMagique[i][i]]
    return newlist

print(diagonale1(CarreMagique))
print(diagonale1(CarreMagiqua))
print(diagonale2(CarreMagique))
print(diagonale2(CarreMagiqua))

def somme_diag1(CarreMagique):
    s = 0
    for i in range(len(CarreMagique)):
        s = s + CarreMagique[i][i]
    return s
print(somme_diag1(CarreMagique))

def somme_diag2(CarreMagique):
    s = 0
    i = 0
    j = len(CarreMagique) - 1
    while(i<len(CarreMagique) and j>=0):
        s = s + CarreMagique[i][j]
        j = j - 1
        i = i + 1
    return s
print(somme_diag2(CarreMagique))
#8
def somme_ligne(CarreMagique, i):
    s = 0
    for j in range(len(CarreMagique)):
        s = s + CarreMagique[i][j]
    return s

def somme_colone(CarreMagique, j):
    s = 0
    for i in range(len(CarreMagique)):
        s = s + CarreMagique[i][j]
    return s

def verif_magique(CarreMagique):
    n = len(CarreMagique)
    s = somme_diag1(CarreMagique)
    for i in range(n):
        if somme_ligne(CarreMagique, i) != s or somme_colone(CarreMagique, i) != s:
            return False
    return s == somme_diag2(CarreMagique)


if verif_magique(CarreMagique) == True:
    print("on a un carré magique")
else:
    print("ce n est pas un carre magique")


