# exercice 2 :

def trianglePascal(n):
    T = [[0] * (n + 1) for p in range(n + 1)]
    for n in range(n + 1):
        if n == 0:
            T[n][0] = 1
        else:
            for k in range(n + 1):
                if k == 0:
                    T[n][0] = 1
                else:
                    T[n][k] = T[n - 1][k - 1] + T[n - 1][k]
    return

T = int(input("choisir un n pour le tr de pascal :"))
print(trianglePascal(T))

def appartient_listeliste (a,b):
    n=len(b[0])
    for i in range (len(b)):
        for j in range (n):
            if b[i][j]==a:
                return (True)
            elif b[i][j]!=a and j==n-1 and i==len(b)-1:
                return (False)